---
name: "openlogos-status"
description: "OpenLogos — OpenLogos status command"
disable-model-invocation: true
---


Check the current OpenLogos project status by running the following steps:

1. Run `openlogos status` in the project root directory.
2. If the `openlogos` command is not found, run `openlogos next` instead.
3. Display the output to the user clearly.
4. Based on the current phase, suggest what the user should do next and which skill to use.
